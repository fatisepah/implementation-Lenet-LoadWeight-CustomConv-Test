In many research projects (for example, in hardware projects), to perform a specific task (for example, changing the multiplication operation, obtaining the maximum, and implementing different functions based on a new hardware), it is necessary to perform that operation in the Forward functions of the layers. different (for example, changing the multiplication operation in the Convolution layer), to do this, we must implement the desired layer as a Custom layer so that we can change its Forward function based on the desired task. Therefore, after writing the Forward function of this layer and putting it instead of nn.conv2d in the network, Train and Test of the network have also been done.


در بسیاری از پروژه های تحقیقاتی (مثلا در پروژه های سخت افزاری) برای انجام یک کار خاص
 (مثلا تغییر عملیات ضرب، بدست آوردن ماکزیمم و پیاده سازی توابع مختلف براساس یک سخت افزار جدید) نیاز است که آن عملیات را در توابع
 Forward 
لایه های مختلف 
(مثلا تغییر عملیات ضرب در لایه 
Convolution) 
تغییر داد، برای انجام این کار باید لایه مورد نظر را به صورت 
Custom layer  
پیاده سازی کرده تا بتوانیم تابع 
Forward 
آن را براساس کار مورد نظر تغییر دهیم. بنابراین بعد از نوشتن تابع 
Forward 
این لایه و قراردادن آن به جای 
nn.conv2d 
در شبکه، 
Train و Test
 شبکه نیز انجام شده است.